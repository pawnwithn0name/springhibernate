# OnlineBankingWebApp-SpringMVC
Banking Management (Admin) Web Application Using Spring MVC Architecture and using Oracle Database.



![Online Bank App](https://github.com/avinash28196/OnlineBankingWebApp-SpringMVC/blob/master/images/BankApp%20(1).gif.crdownload.gif)


ACHITECURE 




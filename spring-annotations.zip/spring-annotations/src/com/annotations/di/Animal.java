package com.annotations.di;

public interface Animal {
	
	public String animalSays();
	
	public String getDailyMeal();

}

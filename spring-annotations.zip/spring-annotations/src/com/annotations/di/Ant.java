package com.annotations.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Ant implements Animal {

	private FoodService foodService;
	
	@Autowired
	public Ant(FoodService ifoodService) {
		this.foodService = ifoodService;
	}
	
	@Override
	public String animalSays() {
		
		return "Ant says hello!!";
	}

	@Override
	public String getDailyMeal() {
		return foodService.foodDelivery();
	}

}

package com.annotations.di;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class CuriousCat implements Animal {
	
	
	private FoodService foodService;
	
	
	@Autowired
	public void setFoodService(FoodService foodService) {
		this.foodService = foodService;
	}

	@Override
	public String animalSays() {
		
		return "meow";
	}

	@Override
	public String getDailyMeal() {
		
		return "Hey Cat," + foodService.foodDelivery();
	}

}

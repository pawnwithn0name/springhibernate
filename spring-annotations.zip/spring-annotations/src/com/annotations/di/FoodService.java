package com.annotations.di;

public interface FoodService {
	public String foodDelivery();
}

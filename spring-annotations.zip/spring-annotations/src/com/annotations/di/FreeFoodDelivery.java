package com.annotations.di;

import org.springframework.stereotype.Component;

@Component
public class FreeFoodDelivery implements FoodService {

	@Override
	public String foodDelivery() {
		return "Eat well!";
	}

}

package com.annotations.di;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ScopeLCMain {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Animal oAnimal = context.getBean("curiousCat", Animal.class);
		Animal oAnimal2 = context.getBean("curiousCat", Animal.class);
		
		
		boolean checkTrue = (oAnimal == oAnimal2);
		
		System.out.println(checkTrue);
		System.out.println("Object1: " + oAnimal);
		System.out.println("Object2: " + oAnimal2);
		
		context.close();
		

	}

}

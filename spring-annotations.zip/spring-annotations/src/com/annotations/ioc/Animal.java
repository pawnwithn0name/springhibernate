package com.annotations.ioc;

public interface Animal {
	
	public String animalSays();

}

package com.annotations.ioc;

import org.springframework.stereotype.Component;

@Component
public class Ant implements Animal {

	@Override
	public String animalSays() {
		
		return "Ant says hello!!";
	}

}

package com.learning.spring;

public interface Instructor {
	
	public String getDailyInstructions();

}

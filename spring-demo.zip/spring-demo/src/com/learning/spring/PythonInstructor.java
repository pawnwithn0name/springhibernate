package com.learning.spring;

public class PythonInstructor implements Instructor {

	@Override
	public String getDailyInstructions() {
		
		return "Learn duck typing in python!";
	}

}

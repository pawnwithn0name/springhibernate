package com.spring.di;

public interface FortuneService {
	
	public String getFortune();

}

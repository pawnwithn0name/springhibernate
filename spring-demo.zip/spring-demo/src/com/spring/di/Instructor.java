package com.spring.di;

public interface Instructor {
	
	public String getDailyInstructions();
	
	public String getDailyFortune();

}

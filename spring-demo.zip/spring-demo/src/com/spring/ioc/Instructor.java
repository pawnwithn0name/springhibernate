package com.spring.ioc;

public interface Instructor {
	
	public String getDailyInstructions();

}

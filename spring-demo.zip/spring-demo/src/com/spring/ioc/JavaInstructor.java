package com.spring.ioc;

public class JavaInstructor implements Instructor {
	
	public String getDailyInstructions() {
		
		return "Practice Multi_Threading!";
	}

}

package com.spring.ioc;

public class PythonInstructor implements Instructor {

	@Override
	public String getDailyInstructions() {
		
		return "Learn duck typing in python!";
	}

}
